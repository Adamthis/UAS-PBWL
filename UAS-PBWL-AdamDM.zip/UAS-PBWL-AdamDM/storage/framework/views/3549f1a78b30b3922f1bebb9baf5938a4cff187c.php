<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src="<?php echo e(asset('images/adam.jpeg')); ?>" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title">Adam DM - 0702193179</h5>
                            <p class="card-text justify">Saya adalah seorang mahasiswa dari Universitas Islam Negeri Sumatera Utara saat Jurusan Sistem Informasi, saat ini saya berada di Semester 6.</p>
                            <a href="#" class="btn btn-primary">Selengkapnya</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
	 
<br>
    <p class="text-sian text-center mt-5">Copyright &copy; <?php if(date('Y') == '2022'): ?>  - 2025  <?php endif; ?> All rights reserved </i> by <a href="https://github.com/adamdmy1/" target="_blank">BERBAGI.COM</a>.</p>
</div>
<?php $__env->stopSection(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
     
</head>
<body>
<footer>
			 
		<div class="social-links-warp">
			<div class="container">
				<div class="social-links">
					<a target="_blank" href="https://www.facebook.com/adam.me/" class="facebook"><i class="fa fa-facebook"></i><span>Facebook</span></a>
					<a target="_blank" href="https://t.me/adamilks" class="telegram"><i class="fa fa-telegram"></i><span>Telegram</span></a>
					<a target="_blank" href="https://www.instagram.com/adam_manurung29/" class="instagram"><i class="fa fa-instagram"></i><span>Instagram</span></a>
					<a target="_blank" href="https://github.com/adamdmy1/" class="github"><i class="fa fa-github"></i><span>github</span></a>
					<a target="_blank" href="https://twitter.com/adamilks" class="twitter"><i class="fa fa-twitter"></i><span>Twitter</span></a>
					<a target="_blank" href="https://api.whatsapp.com/send?phone=6282248954343" class="whatsapp"><i class="fa fa-whatsapp"></i><span>Whatsapp</span></a>
					<a target="_blank" href="https://www.youtube.com/" class="youtube"><i class="fa fa-youtube"></i><span>Youtube</span></a>
				</div>
				
			</div>
		</div> 
	</section>

    </footer>
</body>
</html>
    
	 


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UAS-PBWL-AdamDM\resources\views/home.blade.php ENDPATH**/ ?>