<?php

namespace App\Http\Controllers;

use App\Models\Pisang;
use Illuminate\Http\Request;

class PisangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $rows = Pisang::all();
        return view('pisang.index', compact('rows'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pisang.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'pis_kode' => 'bail|required|unique:tb_pisang',
            'pis_nama' => 'required'
            ],
            [
                'pis_kode.required' => 'KODE wajib diisi',
                'pis_kode.unique' => 'KODE sudah ada',
                'pis_nama.required' => 'Nama wajib diisi'
            ]);
            
            Pisang::create([
                'pis_kode' => $request->pis_kode,
                'pis_nama' => $request->pis_nama
                ]);
                
                return redirect('pisang');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $row = Pisang::findOrFail($id);
        return view('pisang.edit', compact('row'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate(
            [
            'pis_kode' => 'bail|required',
            'pis_nama' => 'required'
            ],
            [
            'pis_kode.required' => 'KODE wajib diisi',
            'pis_nama.required' => 'NAMA wajib diisi'
            ]
            );
            
            $row = Pisang::findOrFail($id);
            $row->update([
            'pis_kode' => $request->pis_kode,
            'pis_nama' => $request->pis_nama,
            ]);
            
            return redirect('pisang');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $row = Pisang::findOrFail($id);
        $row->delete();

        return redirect('pisang');
    }
}
