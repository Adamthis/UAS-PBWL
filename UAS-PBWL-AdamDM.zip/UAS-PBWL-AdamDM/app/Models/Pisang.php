<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pisang extends Model
{
    use HasFactory;

    protected $table = "tb_pisang";

    protected $primaryKey = "pis_id";

    protected $guarded = [];
}
